//custom

function handleRates(rate){
    var html=''
    for(let i=0; i<rate; i++){
        html+=`<small class="fa fa-star text-primary"></small>`
    }

    return html;
}
function displayRooms(json){
    let html = `<div class="container-xxl py-5">
    <div class="container">
        <div class="row g-4">`


    for(let room of json){
        html+=`
<div class="col-lg-4 col-md-6">

<div class="room-item shadow rounded overflow-hidden">
    <div class="position-relative">
        <img class="img-fluid" src="img/${room.primary_image.src}" alt="Image of ${room.name}">
        <small
            class="position-absolute start-0 top-100 translate-middle-y bg-primary text-white rounded py-1 px-3 ms-4">${room.active_price.price}/Night</small>
    </div>
    <div class="p-4 mt-2">
        <div class="d-flex justify-content-between mb-3">
            <h5 class="mb-0">${room.name}</h5>
            <div class="ps-2">

                ${handleRates(room.rate)}

            </div>
        </div>

        <p class="text-body mb-3">${room.description}</p>


    </div>
</div>
 </div>
            `
    }


    html+=`        </div>
    </div>
</div>`

    let roomsBlock = document.getElementById('rooms');
    roomsBlock.innerHTML=html;
}

function resetFilter(){
    fetch('/rooms/getAllRooms', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
        }
    })
        .then(response => response.json())
        .then(data => {
            displayRooms(data);
        })
        .catch((error) => {
            console.error('Error:', error);
        });
}

function applyFilter() {


    const checkboxes = document.querySelectorAll('input[name="rates[]"]:checked');
    let checkedValues = [];
    checkboxes.forEach((checkbox) => {
        checkedValues.push(checkbox.value);
    });


    const minValue = document.getElementById('min').value;
    const maxValue = document.getElementById('max').value;


    const data = {
        rates: checkedValues,
        min: minValue,
        max: maxValue
    };


    fetch('/rooms/filter', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
        },
        body: JSON.stringify(data)
    })
        .then(response => response.json())
        .then(data => {
            displayRooms(data);
        })
        .catch((error) => {
            console.error('Error:', error);
        });


    checkboxes.forEach((checkbox) => {
        checkbox.checked = false;
    });


    document.getElementById('min').value = '';
    document.getElementById('max').value = '';


}



function showResponse(json){
    document.getElementById('responseMsg').innerText=json.msg;

}


const baseURL = "http://127.0.0.1:8000";
$(document).ready(function(){


    document.getElementById('newsletterBtn').addEventListener('click', function() {

        var email = document.getElementById('emailSubscr').value;

        fetch(baseURL+'/subscribeToNewsletter/'+email, {
            // <meta name="csrf-token" content="{{ csrf_token() }}"> ovo sam dodao u head tag
            headers:{'X-Requested-With': 'XMLHttpRequest'},

            method :'GET'
        })
            .then(response=>response.json())
            .then(json=>showResponse(json))


    });

});


$(document).ready(function() {
    $('#confirm-btn').click(function() {

        var startDate = $('#start-date-hidden').val();
        var endDate = $('#end-date-hidden').val();
        var room = $('#room-id-hidden').val();
        var csrfToken = $('meta[name="csrf-token"]').attr('content');

        $.ajax({
            url: '/makeReservation',
            method: 'POST',
            data: {
                'start-date': startDate,
                'end-date': endDate,
                'room': room,
                _token: csrfToken
            },
            success: function(response) {
                let msg = `<p>${response.message}</p>`
                document.getElementById("info-box").innerHTML=msg;
                console.log(response);
            },
            error: function(error) {
                console.error('Error making reservation:', error);
                alert('Error confirming reservation. Please try again.');
            }
        });
    });
});





    document.addEventListener('DOMContentLoaded', function () {
    const message = document.getElementById('successMessage');
    if (message) {
    setTimeout(function () {
    message.style.display = 'none';
}, 3000);
}
});
















//template
(function ($) {
    "use strict";

    // Spinner
    var spinner = function () {
        setTimeout(function () {
            if ($('#spinner').length > 0) {
                $('#spinner').removeClass('show');
            }
        }, 1);
    };
    spinner();


    // Initiate the wowjs
    new WOW().init();


    // Dropdown on mouse hover
    const $dropdown = $(".dropdown");
    const $dropdownToggle = $(".dropdown-toggle");
    const $dropdownMenu = $(".dropdown-menu");
    const showClass = "show";

    $(window).on("load resize", function() {
        if (this.matchMedia("(min-width: 992px)").matches) {
            $dropdown.hover(
            function() {
                const $this = $(this);
                $this.addClass(showClass);
                $this.find($dropdownToggle).attr("aria-expanded", "true");
                $this.find($dropdownMenu).addClass(showClass);
            },
            function() {
                const $this = $(this);
                $this.removeClass(showClass);
                $this.find($dropdownToggle).attr("aria-expanded", "false");
                $this.find($dropdownMenu).removeClass(showClass);
            }
            );
        } else {
            $dropdown.off("mouseenter mouseleave");
        }
    });


    // Back to top button
    $(window).scroll(function () {
        if ($(this).scrollTop() > 300) {
            $('.back-to-top').fadeIn('slow');
        } else {
            $('.back-to-top').fadeOut('slow');
        }
    });
    $('.back-to-top').click(function () {
        $('html, body').animate({scrollTop: 0}, 1500, 'easeInOutExpo');
        return false;
    });


    // Facts counter
    $('[data-toggle="counter-up"]').counterUp({
        delay: 10,
        time: 2000
    });




    // Testimonials carousel
    $(".testimonial-carousel").owlCarousel({
        autoplay: true,
        smartSpeed: 1000,
        margin: 25,
        dots: false,
        loop: true,
        nav : true,
        navText : [
            '<i class="bi bi-arrow-left"></i>',
            '<i class="bi bi-arrow-right"></i>'
        ],
        responsive: {
            0:{
                items:1
            },
            768:{
                items:2
            }
        }
    });

})(jQuery);



