export interface IBooking {
    startDate: string; 
    endDate: string;  
    roomType: number;  
    numberOfGuests: number; 
  }
  