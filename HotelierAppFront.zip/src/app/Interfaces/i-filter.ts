export interface IFilter {
    rates: number[];
    minPrice:number;
    maxPrice:number;
}
