export interface IMenu {
    id:number;
    name:string;
    route:string;
}
