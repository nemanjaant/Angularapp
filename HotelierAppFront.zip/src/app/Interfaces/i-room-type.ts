export interface IRoomType {
    id:number;
    name:string;
}
