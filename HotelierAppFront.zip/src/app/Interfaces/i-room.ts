export interface IRoom {
    id: number;
    name: string;
    active_price: {
      price: number;
    };
    primary_image: {
      src: string;
    };
    averageRate: number;
    description: string;
  }
  