import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IBooking } from '../Interfaces/i-booking';

@Injectable({
  providedIn: 'root'
})
export class BookingService {


  constructor(private http: HttpClient) {}

  checkAvailability(data: IBooking): Observable<any> {
    let url = 'http://127.0.0.1:8000/api/checkAvailability'; 
    return this.http.post<any>(url, data);
  }

  makeAReservation(reservationData: any): Observable<any> {
    let url = 'http://127.0.0.1:8000/api/makeReservation';  
    return this.http.post(url, reservationData);
  }

  deleteReservation(reservationId: number): Observable<any> {
    let url = 'http://127.0.0.1:8000/api/deleteReservation/'+reservationId;  
    return this.http.delete(url);
  }
  

  
}
