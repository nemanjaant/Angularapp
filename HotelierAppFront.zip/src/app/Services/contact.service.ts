import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { IMessage } from '../Interfaces/i-message';

@Injectable({
  providedIn: 'root',
})
export class ContactService {
  private url = 'http://127.0.0.1:8000/api/submit'; 

  constructor(private http: HttpClient) {}

  submitContactForm(contactData: IMessage): Observable<IMessage> {
    return this.http.post<any>(this.url, contactData);
  }
  
}
