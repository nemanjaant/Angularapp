import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';
import {IMenu} from '../Interfaces/i-menu'

@Injectable({
  providedIn: 'root'
})
export class MenuService {

  constructor(private http: HttpClient) { }
  
   
  url: string = "http://127.0.0.1:8000/api/getMenu";

  getMenu(): Observable<IMenu[]>{
    return this.http.get<IMenu[]>(this.url);
  }
 
}