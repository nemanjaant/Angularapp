import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { IRoom } from '../Interfaces/i-room';
import { IFilter } from '../Interfaces/i-filter';

@Injectable({
  providedIn: 'root'
})
export class RoomService {

  

  constructor(private http: HttpClient) {}

  private urlgetRooms = 'http://127.0.0.1:8000/api/rooms/getAllRooms'; 
  getRooms(): Observable<IRoom[]> {
    return this.http.post<IRoom[]>(this.urlgetRooms, {});
  }

  private urlgetFilteredRooms = 'http://127.0.0.1:8000/api/rooms/filter'; 
  getFilteredRooms(filter: IFilter): Observable<any[]> {
    
    return this.http.post<any[]>(this.urlgetFilteredRooms, filter);

    
  }
}
