import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SubscribeService {
  private url = 'http://127.0.0.1:8000/api/subscribeToNewsletter';

  constructor(private http: HttpClient) {}

  subscribe(email: string): Observable<any> {
    const fullUrl = `${this.url}/${encodeURIComponent(email)}`;
    return this.http.get(fullUrl);
  }
}
