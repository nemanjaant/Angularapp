import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RoomtypesService } from '../../Services/room-type.service';
import { IRoomType } from '../../Interfaces/i-room-type';
import { IBooking } from '../../Interfaces/i-booking';
import { Router } from '@angular/router';
import { BookingService } from '../../Services/booking.service';
import { bookingDatesValidator } from '../../validators/bookingDateValidator.validator';

@Component({
  selector: 'app-booking-form',
  templateUrl: './booking-form.component.html',
  styleUrls: ['./booking-form.component.css']
})
export class BookingFormComponent implements OnInit {
  bookingForm: FormGroup;
  rooms : IRoomType[];

  constructor(private fb: FormBuilder, private roomTypeService: RoomtypesService, private bookingService: BookingService, private router: Router) {}

  ngOnInit(): void {
    this.bookingForm = this.fb.group({
      startDate: ['', Validators.required],
      endDate: ['', Validators.required],
      roomType: ['', Validators.required],
      numberOfGuests: [1, [Validators.required, Validators.min(1), Validators.max(4)]]
    },{ validators: bookingDatesValidator() });

    this.roomTypeService.getRoomTypes().subscribe({
      next: data => {
        this.rooms = data; 
        console.log(this.rooms)
           
      },
      error: err => {
        console.log(err);
      }
    })

    this.bookingForm.get('roomType')?.valueChanges.subscribe(() => {
      this.validateNumberOfGuests();
    });

    
    this.bookingForm.get('numberOfGuests')?.valueChanges.subscribe(() => {
      this.validateNumberOfGuests();
    });

    
  }

  onSubmit() {
    if (this.bookingForm.valid) {
      const reservationData: IBooking = this.bookingForm.value;
      this.bookingService.checkAvailability(reservationData).subscribe(response => {
        this.router.navigate(['/booking'], { state: { bookingInfo: response } });
      });
    }
  }


  incrementGuests() {
    const roomTypeId = this.bookingForm.get('roomType')?.value;
    let currentValue = this.bookingForm.get('numberOfGuests')?.value;
    console.log(currentValue);

    if (roomTypeId){
      if(roomTypeId==1){

        if (currentValue > 1) {
          this.bookingForm.get('numberOfGuests')?.setValue(1);
        }
        if (currentValue < 1) {
          this.bookingForm.get('numberOfGuests')?.setValue(currentValue + 1);
        }
      }

      else if(roomTypeId==2){

        if (currentValue > 2) {
          this.bookingForm.get('numberOfGuests')?.setValue(1);
        }
        if (currentValue < 2) {
          this.bookingForm.get('numberOfGuests')?.setValue(currentValue + 1);
        }
      }

      else if(roomTypeId==3){

        if (currentValue > 3) {
          this.bookingForm.get('numberOfGuests')?.setValue(1);
        }
        if (currentValue < 3) {
          this.bookingForm.get('numberOfGuests')?.setValue(currentValue + 1);
        }
      }

      else {
        if (currentValue < 4) {
          this.bookingForm.get('numberOfGuests')?.setValue(currentValue + 1);
        }
      }
      
    }
    
  }

  decrementGuests() {
    let currentValue = this.bookingForm.get('numberOfGuests')?.value;
    if (currentValue > 1) {
      this.bookingForm.get('numberOfGuests')?.setValue(currentValue - 1);
    }
  }

  getMaxGuests(roomTypeId: number): number {
    
    if(roomTypeId==1){

      return 1;
      
    }

    else if(roomTypeId==2){
      
      return 2;
      
    }

    else if(roomTypeId==3){

      return 3;
     
    } 

    else return 4;
  }

  validateNumberOfGuests(): void {
    const roomTypeId = this.bookingForm.get('roomType')?.value;
    const numberOfGuests = this.bookingForm.get('numberOfGuests')?.value;

    if (roomTypeId) {
      const maxGuests = this.getMaxGuests(roomTypeId);
      if (numberOfGuests > maxGuests) {
        
        this.bookingForm.get('numberOfGuests')?.setValue(1, { emitEvent: false });
      }
    }
  }
}
