import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BookingService } from '../../Services/booking.service';

@Component({
  selector: 'app-booking-info',
  templateUrl: './booking-info.component.html',
  styleUrls: ['./booking-info.component.css']
})
export class BookingInfoComponent implements OnInit {
  bookingInfo: any;
  successMessage: string = '';
  reservationId: number = 0;

  constructor(private router: Router, private bookingService: BookingService) {}

  ngOnInit(): void {
    this.bookingInfo = history.state.bookingInfo;
    console.log(this.bookingInfo);
  }

  confirmReservation(): void {
  const reservationData = {
    startDate: this.bookingInfo.startDate,
    endDate: this.bookingInfo.endDate,
    roomId: this.bookingInfo.room.id
  };

  this.bookingService.makeAReservation(reservationData).subscribe(
    response => {
      
      this.successMessage = 'Reservation successfully made!';
      this.reservationId = response.reservationId;
      
    },
    error => {
      console.error('Reservation failed:', error);
      
    }
  );
}
  updateReservation(reservationId: number): void {
    console.log('Update', reservationId);
  }

  deleteReservation(reservationId: number): void {
    
    this.bookingService.deleteReservation(reservationId).subscribe(
      response => {
        console.log('Reservation deleted:', response.message);
        this.successMessage = 'Reservation successfully deleted!';
        
      },
      error => {
        console.error('Failed to delete reservation:', error);
        this.successMessage = 'Failed to delete reservation. Please try again.';
      }
    );
  }
  
}
