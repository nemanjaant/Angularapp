import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BookingRoutingModule } from './booking-routing.module';
import { BookingFormComponent } from './booking-form/booking-form.component';
import { ReactiveFormsModule } from '@angular/forms';
import { BookingInfoComponent } from './booking-info/booking-info.component';


@NgModule({
  declarations: [
    BookingFormComponent,
    BookingInfoComponent
    
  ],
  imports: [
    CommonModule,
    BookingRoutingModule,
    ReactiveFormsModule
  ],
  exports:[
    BookingFormComponent
  ]
})
export class BookingModule { }
