import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HomeRoutingModule } from './home-routing.module';
import { HomePageComponent } from './home-page/home-page.component';
import { CarouselComponent } from './carousel/carousel.component';
import { BookingModule } from '../booking/booking.module';
import { RoomModule } from '../room/room.module';
import { PromoModule } from '../promo/promo.module';


@NgModule({
  declarations: [
    HomePageComponent,
    CarouselComponent
  ],
  imports: [
    CommonModule,
    HomeRoutingModule,
    BookingModule,
    RoomModule,
    PromoModule
  ]
})
export class HomeModule { }
