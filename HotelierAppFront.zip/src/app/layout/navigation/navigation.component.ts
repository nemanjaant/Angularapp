import { Component } from '@angular/core';
import { IMenu } from '../../Interfaces/i-menu';
import { MenuService } from '../../Services/menu.service';

@Component({
  selector: 'app-navigation',
  templateUrl: './navigation.component.html',
  styleUrl: './navigation.component.css'
})
export class NavigationComponent {

  menu: IMenu[] = [];

  constructor(private menuservice: MenuService) { }


  ngOnInit(): void {
    this.menuservice.getMenu().subscribe({
      next: data => {
        this.menu = data; 
        //console.log(this.menu)
           
      },
      error: err => {
        console.log(err);
      }
    })
  }

}
