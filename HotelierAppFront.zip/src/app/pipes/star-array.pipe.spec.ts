import { StarArrayPipe } from './star-array.pipe';

describe('StarArrayPipe', () => {
  it('create an instance', () => {
    const pipe = new StarArrayPipe();
    expect(pipe).toBeTruthy();
  });
});
