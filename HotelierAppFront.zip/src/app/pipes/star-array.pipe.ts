import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'starArray',  
  standalone: true
})
export class StarArrayPipe implements PipeTransform {
  transform(rate: number): number[] {
    return Array.from({ length: rate }, (value, index) => index);
  }
}
