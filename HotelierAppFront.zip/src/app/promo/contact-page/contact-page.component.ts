import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ContactService } from '../../Services/contact.service';

@Component({
  selector: 'app-contact-page',
  templateUrl: './contact-page.component.html',
  styleUrls: ['./contact-page.component.css']
})
export class ContactPageComponent implements OnInit {
  contactForm: FormGroup;
  successMessage: string;
  errorMessage: string;
  submitted: boolean;

  constructor(private fb: FormBuilder, private contactService: ContactService) {}

  ngOnInit(): void {
    this.contactForm = this.fb.group({
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      subject: ['', Validators.required],
      message: ['', Validators.required],
    });
  }

  onSubmit() {
    this.submitted = true;

    
    if (this.contactForm.valid) {
      const formData = this.contactForm.value; 
      console.log('form data:')
      console.log(formData)

      
      this.contactService.submitContactForm(formData).subscribe({
        next: (response) => {
          this.successMessage = 'Message sent successfully!';
          this.errorMessage = ''; 
          this.contactForm.reset(); 
          this.submitted = false;
        },
        error: (error: HttpErrorResponse) => {
          this.successMessage = ''; 
          this.errorMessage = 'Failed to send the message. Please try again.';
        }
      });
    } else {
      
      alert('Please fill out the form correctly.');
    }
  }
}
