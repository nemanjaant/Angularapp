import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SubscribeService } from '../../Services/subscribe.service';

@Component({
  selector: 'app-newsletter',
  templateUrl: './newsletter.component.html',
  styleUrls: ['./newsletter.component.css']
})
export class NewsletterComponent {
  newsletterForm: FormGroup;
  responseMessage: string | null = null;

  constructor(
    private fb: FormBuilder,
    private subscribeService: SubscribeService
  ) {
    this.newsletterForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]]
    });
  }

  subscribe(): void {
    if (this.newsletterForm.valid) {
      const email = this.newsletterForm.value.email;
      this.subscribeService.subscribe(email).subscribe({
        next: () => this.responseMessage = 'Subscription successful!',
        error: () => this.responseMessage = 'Subscription failed. Please try again later.'
      });
    } else {
      this.responseMessage = 'Please enter a valid email address.';
    }
  }
}
