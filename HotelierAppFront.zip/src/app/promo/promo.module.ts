import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PromoRoutingModule } from './promo-routing.module';
import { NewsletterComponent } from './newsletter/newsletter.component';
import { ReactiveFormsModule } from '@angular/forms';
import { AboutPageComponent } from './about-page/about-page.component';
import { ContactPageComponent } from './contact-page/contact-page.component';


@NgModule({
  declarations: [
    NewsletterComponent,
    AboutPageComponent,
    ContactPageComponent
  ],
  imports: [
    CommonModule,
    PromoRoutingModule,
    ReactiveFormsModule 
  ],
  exports :[
    NewsletterComponent
  ]
})
export class PromoModule { }
