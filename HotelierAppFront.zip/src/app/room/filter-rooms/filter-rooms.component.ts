import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, Validators } from '@angular/forms';
import { IFilter } from '../../Interfaces/i-filter';

@Component({
  selector: 'app-filter-rooms',
  templateUrl: './filter-rooms.component.html',
  styleUrls: ['./filter-rooms.component.css']
})
export class FilterRoomsComponent implements OnInit {
  filterForm: FormGroup;
  starRatings = [5, 4, 3, 2, 1];

  @Output() filterApplied = new EventEmitter<IFilter>(); 

  
  constructor(private fb: FormBuilder) {
    
    this.filterForm = this.fb.group({
      rates: this.fb.array([]),  
      minPrice: [0, Validators.required],
      maxPrice: [0, Validators.required]
    });
  }

  ngOnInit(): void {
    
  }

  onCheckboxChange(event: any) {
    const ratesArray: FormArray = this.filterForm.get('rates') as FormArray;

    if (event.target.checked) {
      
      ratesArray.push(this.fb.control(+event.target.value)); 
    } else {
      
      const index = ratesArray.controls.findIndex(x => x.value === +event.target.value);
      ratesArray.removeAt(index);
    }
  }

  applyFilter() {
    const filterCriteria: IFilter = this.filterForm.value;
    
    this.filterApplied.emit(filterCriteria); 
  }

  
  
  resetFilter() {

    const ratesArray: FormArray = this.filterForm.get('rates') as FormArray;
    while (ratesArray.length !== 0) {
      ratesArray.removeAt(0); 
    }
    this.filterForm.reset({
      rates: [],  
      minPrice: 0,
      maxPrice: 0
    });

    this.starRatings.forEach(rate => {
      const checkbox = document.getElementById('rate' + rate) as HTMLInputElement;
      if (checkbox) {
        checkbox.checked = false; 
      }
    });

    this.filterApplied.emit({ rates: [], minPrice: 0, maxPrice: 0 });  
  }

  
}
