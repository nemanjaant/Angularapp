import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-room-card',
  templateUrl: './room-card.component.html',
  styleUrls: ['./room-card.component.scss']
})
export class RoomCardComponent {
[x: string]: any;
  @Input() price!: number;
  @Input() image!: string;
  @Input() name!: string;
  @Input() rate!: number;
  @Input() description!: string;
  @Input() id!: number;


  
}