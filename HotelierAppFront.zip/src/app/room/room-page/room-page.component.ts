import { Component } from '@angular/core';
import { IFilter } from '../../Interfaces/i-filter';

@Component({
  selector: 'app-room-page',
  templateUrl: './room-page.component.html',
  styleUrl: './room-page.component.css'
})
export class RoomPageComponent {
  filterCriteria: IFilter; 

  onFilterApplied(criteria: IFilter) {
    this.filterCriteria = criteria; 
    console.log(this.filterCriteria);
  }
}
