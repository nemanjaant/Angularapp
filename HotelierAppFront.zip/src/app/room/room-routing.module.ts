import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FilterRoomsComponent } from './filter-rooms/filter-rooms.component';
import { RoomPageComponent } from './room-page/room-page.component';


const routes: Routes = [
  {
    path: "",
    component: RoomPageComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)], 
  exports: [RouterModule]
})
export class RoomRoutingModule { }
