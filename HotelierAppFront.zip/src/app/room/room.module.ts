import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RoomsComponent } from './rooms/rooms.component';
import { RoomCardComponent } from './room-card/room-card.component';
import { StarArrayPipe } from '../pipes/star-array.pipe';
import { FilterRoomsComponent } from './filter-rooms/filter-rooms.component';
import { ReactiveFormsModule } from '@angular/forms';
import { RoomRoutingModule } from './room-routing.module';
import { RoomPageComponent } from './room-page/room-page.component';


@NgModule({
  declarations: [
    RoomsComponent,
    RoomCardComponent,
    FilterRoomsComponent,
    RoomPageComponent
  ],
  imports: [
    CommonModule,
    StarArrayPipe,
    ReactiveFormsModule,
    RoomRoutingModule
    
  ],
  exports: [
    RoomsComponent,
    RoomCardComponent
  ]
})
export class RoomModule { }
