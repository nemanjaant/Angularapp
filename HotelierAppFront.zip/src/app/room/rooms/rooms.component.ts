import { Component, Input, OnInit, SimpleChanges } from '@angular/core';
import { RoomService } from '../../Services/room.service'; 
import { IRoom } from '../../Interfaces/i-room';
import { IFilter } from '../../Interfaces/i-filter';

@Component({
  selector: 'app-rooms',
  templateUrl: './rooms.component.html',
  styleUrls: ['./rooms.component.css']
})
export class RoomsComponent implements OnInit {

  @Input() homePage: boolean = false;
  @Input() filter: IFilter;
   
  rooms: IRoom[] = [];

  constructor(private roomService: RoomService) {}


  ngOnInit(): void {
    if(this.homePage==true){
      this.getRooms();
  }
  else{
    if(!this.filter){
      this.getRooms();
    }
    
  }
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes['filter'] && this.filter) {
      if(this.filter.maxPrice==0 && this.filter.minPrice==0 && this.filter.rates.length==0){
        console.log('sve sobe');
        this.getRooms();
      }
      else {
        this.getFilteredRooms(this.filter);
      }
    }
  }

  getFilteredRooms(criteria: IFilter) {
    this.roomService.getFilteredRooms(criteria).subscribe((rooms: any[]) => {
      this.rooms = rooms;
    });
  }

  getRooms(): void {
    this.roomService.getRooms().subscribe(
      (data: any[]) => {
        this.rooms = data;
      },
      (error) => {
        console.log('Error: ', error);
      }
    );
  }

  
  
}
