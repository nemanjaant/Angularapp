import { AbstractControl, ValidationErrors, ValidatorFn, FormGroup } from '@angular/forms';


export function bookingDatesValidator(): ValidatorFn {
  return (formGroup: AbstractControl): ValidationErrors | null => {
    const startDateControl = formGroup.get('startDate');
    const endDateControl = formGroup.get('endDate');

    if (!startDateControl || !endDateControl) {
      return null;
    }

    const startDate = new Date(startDateControl.value);
    const endDate = new Date(endDateControl.value);
    const today = new Date();
    today.setHours(0, 0, 0, 0); 

    const errors: ValidationErrors = {};

    
    if (startDate < today) {
      errors['startDateBeforeToday'] = true;
    }

   
    if (endDate < startDate) {
      errors['endDateBeforeStartDate'] = true;
    }

    return Object.keys(errors).length > 0 ? errors : null;
  };
}
