<?php

namespace App\Http\Controllers;

use App\Http\Requests\LoginRequest;
use App\Http\Requests\RegistrationRequest;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{

    public function loginForm(){

        return view('pages.login');
    }

    public function doLogin(LoginRequest $request){

        $validated = $request->validated();

        $email = $validated['email'];
        $password = $validated['password'];

        $user = User::where('email',$email)->first();

        if(!$user){
            return redirect()->back()->with('error-msg', 'Wrong email address. Please try again.');
        }

        if(!Hash::check($password, $user->password)){
            return redirect()->back()->with('error-msg', 'Wrong password. Please try again.');
        }

        Auth::login($user);
        return redirect()->route('home');


    }

    public function logout(){

        Auth::logout();
        return redirect()->route('login');
    }

    public function registration(){
        return view('pages.registration');
    }

    public function register(RegistrationRequest $request){


        $validated = $request->validated();


        $user = User::create([
            'first_name' => $validated['first_name'],
            'last_name' => $validated['last_name'],
            'email' => $validated['email'],
            'password' => Hash::make($validated['password']),
        ]);


        Auth::login($user);

        return redirect()->route('home')->with('success', 'You have successfully registered. Enjoy our services!');



    }
}
