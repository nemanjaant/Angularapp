<?php

namespace App\Http\Controllers;

use App\Models\Messages;
use Illuminate\Http\Request;

class ContactController extends Controller
{
    public function contactPage(){
        return view('pages.contact');
    }

    public function processContactFormData(Request $request){

        $validatedData = $request->validate([
            'name' => 'required|max:255',
            'email' => 'required|email',
            'subject' => 'required',
            'message' => 'required',
        ]);
        try{
            if($validatedData){

                $newMessage = new Messages();
                $newMessage->name = $request->name;
                $newMessage->email = $request->email;
                $newMessage->subject = $request->subject;
                $newMessage->message = $request->message;
                $newMessage->save();

                return response()->json(['success' => 'We have received your message!']);

            }

            else return response()->json(['error' => 'Sorry, something went wrong. We have not received your message!']);

        }



        catch(\Exception $ex){
            return response()->json(['error' => $ex->getMessage()]);
        }

    }

    public function showMessages(){
        $messages = Messages::get();

        return view('admin_front.pages.messages',compact('messages'));
    }
}
