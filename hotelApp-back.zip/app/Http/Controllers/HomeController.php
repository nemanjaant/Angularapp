<?php

namespace App\Http\Controllers;

use App\Models\Menu;
use App\Models\Room;
use App\Models\RoomType;
use App\Models\Service;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class HomeController extends Controller
{
    public function index(){

        $carouselImages = DB::table('carousel_images')->get();
        $services = Service::all();
        $rooms = RoomType::with(['activePrice','primaryImage'])->where('is_available',true)->get();
        $isHomePage = true;


        return view('pages.home', compact('carouselImages', 'services', 'rooms', 'isHomePage'));
    }
}
