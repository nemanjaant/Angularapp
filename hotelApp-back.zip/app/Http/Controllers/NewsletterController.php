<?php

namespace App\Http\Controllers;

use ErrorException;
use Illuminate\Http\Request;
use Mockery\Exception;

class NewsletterController extends Controller
{
    public function subscribe($email){

        $file = 'newsletter/newsletter.txt';
        $content = $email."\n";
        $message = "";

        try{

            if (!filter_var(trim($content), FILTER_VALIDATE_EMAIL)) {
                $message = "Invalid email address.";
                return response()->json(['msg'=>$message] );
            }

            $currentContent = file_exists($file) ? file_get_contents($file) : '';

            if (strpos($currentContent, $content) === false) {

                $handle = fopen($file, 'a');
                if ($handle === false) {
                    $message = "Something went wrong. Please try subscribing later.";
                }


                if (fwrite($handle, $content) === false) {
                    $message = "Something went wrong. Please try subscribing later.";
                    fclose($handle);
                }

                $message =  "You have subscribed successfully. Thank you!";

                fclose($handle);
                return response()->json(['msg'=>$message] );

            }

            else {

                $message =  "You are already subscribed. Thank you!";
                return response()->json(['msg'=>$message] );

            }
        }

        catch (ErrorException){
            $message = "Something went wrong. Please try subscribing later.";
            return response()->json(['msg'=>$message] );
        }

    }
}
