<?php

namespace App\Http\Controllers;

use App\Models\Reservation;
use App\Models\RoomType;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class ReservationController extends Controller
{
    public function checkAvailability(Request $request){

        $validatedData = $request->validate([
            'startDate' => 'required|date',
            'endDate' => 'required|date|after:start-date',
            'roomType' => 'required|exists:room_types,id',
            'numberOfGuests' => 'required|integer|min:1|max:4'
        ]);


        $startDate = $validatedData['startDate'];
        $endDate = $validatedData['endDate'];
        $roomType = $validatedData['roomType'];
        $numberOfGuests = $validatedData['numberOfGuests'];
        $data = [];

        $reservedRooms = DB::table('rooms')
            ->where('room_type_id', $roomType)
            ->where('number_of_beds', '>=', $numberOfGuests)
            ->join('room_reservation', 'rooms.id', '=', 'room_reservation.room_id')
            ->join('reservations', 'room_reservation.reservation_id', '=', 'reservations.id')
            ->where('reservations.check_in', '>=', $startDate)
            ->where('reservations.check_out', '<=', $endDate)
            ->select('rooms.id')
            ->get();

        $reservedRoomIds = $reservedRooms->pluck('id');

        $availableRoomWithPrice = DB::table('rooms')
            ->where('rooms.room_type_id', $roomType)
            ->where('is_available',true)
            ->where('number_of_beds', '>=', $numberOfGuests)
            ->whereNotIn('rooms.id', $reservedRoomIds)
            ->join('room_prices', function ($join) {
                $join->on('rooms.room_type_id', '=', 'room_prices.room_type_id')
                    ->where('room_prices.is_active', true);
            })
            ->select('rooms.*', DB::raw("room_prices.price * {$numberOfGuests} as room_price"))
            ->first();


        if($availableRoomWithPrice){

            $numberOfDays = (strtotime($endDate)-strtotime($startDate))/86400;
            $availableRoomWithPrice->room_price = $availableRoomWithPrice->room_price * $numberOfDays;
            $roomTypes = RoomType::all();

            $data = [
                'room' => $availableRoomWithPrice,
                'roomTypes' => $roomTypes,
                'startDate' => $startDate,
                'endDate' => $endDate,
            ];

        }


        return response()->json($data);



    }

    public function makeReservation(Request $request){

        $startDate = $request->input('startDate');
        $endDate = $request->input('endDate');
        $roomId = $request->input('roomId');

//        if (!Auth::check()) {
//            return response()->json(['message' => 'You need to be logged in to make a reservation.', 'status' => 401]);
//        }

        //$userId = Auth::user()->id;
        $userId = 1;


        DB::beginTransaction();

        try {
            $reservation = new Reservation([
                'user_id' => $userId,
                'check_in' => $startDate,
                'check_out' => $endDate,
            ]);

            $reservation->save();


            DB::table('room_reservation')->insert([
                'room_id' => $roomId,
                'reservation_id' => $reservation->id,
            ]);

            DB::commit();

            return response()->json(['message' => 'Reservation successfully made!', 'reservationId'=>$reservation->id]);

        } catch (\Exception $e) {
            DB::rollback();
            return response()->json(['message' => $e->getMessage()], 500);
        }


    }

    public function deleteReservation(int $id)
    {
        DB::beginTransaction();

        try {

            DB::table('room_reservation')
                ->where('reservation_id', $id)
                ->delete();



            DB::commit();
            return response()->json(['message' => 'Reservation successfully deleted!']);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

}
