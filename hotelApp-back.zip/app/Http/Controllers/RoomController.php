<?php

namespace App\Http\Controllers;

use App\Models\Room;
use App\Models\RoomPrice;
use App\Models\RoomType;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;

class RoomController extends Controller
{
    public function showRooms($id=null){

        $rooms = RoomType::with(['activePrice','primaryImage'])->where('is_available',true)->get();
        $isHomePage = false;


        return response()->json($rooms);

    }

    public function showRoomTypesAdmin(){
        $rooms = RoomType::with(['activePrice'])->where('is_available',true)->get();

        return view('admin_front.pages.admin_roomTypes', compact('rooms'));
    }

    public function showRoomTypes(){
        $rooms = RoomType::where('is_available', true)->get();
        return response()->json($rooms);
    }


    public function showRoom(){
        return view('pages.room');

    }

    public function filterRooms(Request $request)
    {
        $rates = $request->input('rates');
        $min = $request->input('minPrice');
        $max = $request->input('maxPrice');

        $rooms = RoomType::with(['activePrice', 'primaryImage'])->where('is_available',true)->get();

        $filteredRooms = [];

        foreach ($rooms as $room) {
            $room->rate = $room->averageRate;


            $rateCondition = true;
            $priceCondition = true;


            if ($rates) {
                $rateCondition = in_array($room->averageRate, $rates);
            }


            if ($min !== null) {
                $priceCondition = $priceCondition && $room->activePrice->price >= $min;
            }
            if ($max !== null && $max != 0) {
                $priceCondition = $priceCondition && $room->activePrice->price <= $max;
            }


            if ($rateCondition && $priceCondition) {
                $filteredRooms[] = $room;
            }
        }

        return response()->json($filteredRooms);
    }

    public function getAllRooms(){
        $rooms = RoomType::with(['activePrice', 'primaryImage'])
            ->where('is_available', true)
            ->get();

        return response()->json($rooms);
    }

    public function editRoomTypePage($id){
        $room = RoomType::with(['activePrice'])->where('is_available',true)->find($id);
        return view('admin_front.pages.edit_room',compact('room'));
    }

    public function updateRoomType(Request $request, $id){



        $request->validate([
            'name'=>'required|min:3',
            'description'=>'required|min:100',
            'price'=>'required|numeric'
        ]);



        try{

            DB::beginTransaction();
            $roomType = RoomType::find($id);
            $roomType->name = $request->name;
            $roomType->description=$request->description;
            $roomType->save();

            $price = RoomPrice::where('room_type_id',$id)->where('is_active',true)->first();
            $price->is_active = false;
            $price->save();

            $newPrice = new RoomPrice();
            $newPrice->price = $request->price;
            $newPrice->room_type_id = $id;
            $newPrice->save();

            DB::commit();

            //return redirect()->route('admin.showRoomTypesAdmin');

            return redirect()->back()->with('success', 'Updated successfully');

        }

        catch(Exception $e){
            DB::rollBack();
            return redirect()->back()->with('error', $e->getMessage());
        }
    }

    public function deleteRoomType($id){

        try {
            DB::beginTransaction();
            $roomType = RoomType::find($id);
            $rooms = Room::where('room_type_id',$id)->get();

            foreach ($rooms as $room) {
                $room->is_available = false;
                $room->save();
            }

            $roomType->is_available = false;
            $roomType->save();


            DB::commit();
            return redirect()->back();

        } catch (Exception $e) {
            DB::rollBack();
            return Redirect::back()->withErrors(['msg' => $e->getMessage()]);
        }

    }




}
