<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RoomType extends Model
{
    use HasFactory;
    protected $appends = ['averageRate'];


    public function rooms(){
        return $this->hasMany(Room::class);
    }

    public function getAverageRateAttribute()
    {
        return round($this->roomRates()->avg('rate_value'));
    }


    public function roomRates()
    {
        return $this->hasMany(RoomRate::class);
    }




    public function images(){
        return $this->hasMany(Image::class);
    }

    public function primaryImage(){
        return $this->hasOne(Image::class)->where('is_primary', true);
    }

    public function roomPrices()
    {
        return $this->hasMany(RoomPrice::class);
    }

    public function activePrice()
    {
        return $this->hasOne(RoomPrice::class)->where('is_active', true);
    }
}
