<?php

namespace App\View\Components;

use Closure;
use Illuminate\View\Component;
use Illuminate\Contracts\View\View;

class reservationForm extends Component
{
    /**
     * Create a new component instance.
     */

    public $rooms;
    public $selectedRoomType;

    public function __construct($rooms, $selectedRoomType=null)
    {
        $this->rooms=$rooms;
        $this->selectedRoomType=$selectedRoomType;
    }

    /**
     * Get the view / contents that represent the component.
     */
    public function render(): View|Closure|string
    {
        return view('components.reservation-form');
    }
}
