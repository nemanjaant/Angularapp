<?php

namespace App\View\Components;

use Closure;
use Illuminate\Contracts\View\View;
use Illuminate\View\Component;

class roomCard extends Component
{

    public $price;
    public $image;
    public $name;
    public $rate;
    public $description;
    public $id;

    public function __construct($price, $image, $name, $rate, $description, $id)
    {
        $this->price = $price;
        $this->image = $image;
        $this->name = $name;
        $this->rate = $rate;
        $this->description = $description;
        $this->id = $id;
    }

    /**
     * Get the view / contents that represent the component.
     */
    public function render(): View|Closure|string
    {
        return view('components.room-card');
    }
}
