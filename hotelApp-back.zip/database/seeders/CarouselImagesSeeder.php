<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CarouselImagesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $images = ['carousel-1.jpg', 'carousel-2.jpg'];

        foreach($images as $img){
            DB::table('carousel_images')->insert(['src'=>$img]);
        }
    }
}
