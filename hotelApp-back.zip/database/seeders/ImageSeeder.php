<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ImageSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $roomTypes = range(1, 6);
        $images = [];

        foreach ($roomTypes as $typeId) {
            $images[] = [
                'src' => "rooms/room-type-{$typeId}.jpg",
                'is_primary' => true,
                'room_type_id' => $typeId,
            ];
        }

        DB::table('images')->insert($images);
    }
}
