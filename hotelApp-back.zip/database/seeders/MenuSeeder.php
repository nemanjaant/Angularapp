<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class MenuSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */

    private $names = ['home', 'about', 'rooms', 'contact'];
    private $routes = ['home', 'about', 'rooms', 'contact'];


    public function run(): void
    {
        for($i = 0; $i < count($this->names); $i++){
            DB::table('menu')->insert([
                'name'=>$this->names[$i], 'route'=>$this->routes[$i]
            ]);
        }
    }
}
