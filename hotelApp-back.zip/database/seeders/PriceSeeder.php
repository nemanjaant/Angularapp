<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class PriceSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $prices = [
            ['room_type_id' => 1, 'price' => 100.00],
            ['room_type_id' => 2, 'price' => 150.00],
            ['room_type_id' => 3, 'price' => 200.00],
            ['room_type_id' => 4, 'price' => 250.00],
            ['room_type_id' => 5, 'price' => 300.00],
            ['room_type_id' => 6, 'price' => 350.00]
        ];

        DB::table('room_prices')->insert($prices);
    }
}
