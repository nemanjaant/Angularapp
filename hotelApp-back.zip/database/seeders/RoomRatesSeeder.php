<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class RoomRatesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $impressions = [
    "Our stay was peaceful and refreshing.",
    "Beautiful views from every room!",
    "The staff made us feel right at home.",
    "Clean rooms, excellent service.",
    "Truly a gem in the city center.",
    "Efficient, courteous, and friendly staff.",
    "Great place for families and singles alike.",
    "A quiet, cozy spot for weekend getaways.",
    "Loved the modern decor in the lobby.",
    "Impeccably clean and well-maintained.",
    "The breakfast buffet was top-notch.",
    "Elegant rooms with comfortable beds.",
    "Prime location near all major attractions.",
    "24/7 concierge services were so helpful.",
    "The pool area was serene and inviting.",
    "Perfect for business and leisure.",
    "Free Wi-Fi was surprisingly fast.",
    "Every request was met with a smile.",
    "The spa services were utterly relaxing.",
    "Ideal for a romantic weekend.",
    "Always a pleasure to stay here.",
    "Accessibility options were excellent.",
    "Pet-friendly and kids love it too!",
    "Our room had a stunning ocean view.",
    "A peaceful retreat from the busy city.",
    "Their attention to detail is unmatched.",
    "Valet parking was quick and easy.",
    "Superb dining options onsite.",
    "Very accommodating for large groups.",
    "A reliable choice for frequent travelers.",
    "Gardens around the hotel were beautiful.",
    "Room service was prompt and courteous.",
    "Fitness center had everything I needed.",
    "The rooftop bar has breathtaking views.",
    "Perfect mix of luxury and comfort.",
    "Daily housekeeping kept things spotless.",
    "Highly recommend their brunch menu.",
    "Quiet AC units in each room.",
    "Functional spaces for meetings and events.",
    "Children’s play area was a nice touch.",
    "Tea and coffee facilities were appreciated.",
    "Check-in and check-out were a breeze.",
    "Felt safe during our entire stay.",
    "Bathrooms were spacious and modern.",
    "Plenty of natural light in the lobby.",
    "They really care about guest experience.",
    "Lush towels and linens provided.",
    "Affordable rates for such luxury.",
    "Effortless reservation process online.",
    "Guest-oriented service, every time."];


        for ($i = 0; $i < 50; $i++) {
            DB::table('room_rates')->insert([
                'room_type_id' => rand(1, 6),
                'rate_value' => rand(1, 5),
                'description' => $impressions[$i]
            ]);
        }
    }
}
