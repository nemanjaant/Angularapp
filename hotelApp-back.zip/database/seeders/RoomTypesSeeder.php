<?php

namespace Database\Seeders;

use App\Models\RoomType;
use App\Models\Service;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Carbon;

class RoomTypesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $roomTypes = [
            [
                'name'=>'Single Room',
                'description' => 'Our Single Room offers a comfortable retreat for solo travelers. Equipped with a plush single bed, a work desk, and complimentary Wi-Fi, this room combines functionality with comfort. The decor is modern and minimalistic, creating a serene space to relax and rejuvenate after a busy day.'

            ],

            [
                'name'=>'Double Room',
                'description' => 'Ideal for couples or friends traveling together, our Double Room features two cozy beds in a beautifully appointed space. Enjoy amenities such as a flat-screen TV, room service, and a private bathroom stocked with luxurious toiletries. The room’s warm lighting and fine linens ensure a restful night’s sleep.'
            ],

            [
                'name'=>'Queen Room',
                'description' => 'The Queen Room offers a spacious setting with a luxurious queen-size bed. Elegant furnishings and a soothing palette create a relaxing ambiance. The room includes modern amenities like a minibar, coffee maker, and a seating area, perfect for both relaxation and work.'

            ],

            [
                'name'=>'King Room',
                'description' => 'Our King Room provides a regal experience with a large king-size bed and premium bedding. The room boasts a sophisticated design with a dedicated workspace, an en-suite bathroom, and a balcony overlooking the surroundings. High-speed Internet and a smart TV are also included for entertainment and convenience.'

            ],

            [
                'name'=>'Suite',
                'description' => 'Experience ultimate luxury in our Suite, featuring a separate living area, bedroom, and sometimes even a kitchenette. The suite is designed for comfort and elegance, providing ample space and upscale amenities tailored for an unforgettable stay. Perfect for those who appreciate finer accommodations.'

            ],

            [
                'name'=>'Family Room',
                'description' => 'Designed for family stays, our Family Room offers multiple bedding options and ample space for everyone. It includes kid-friendly amenities, entertainment options, and safety features to ensure a comfortable and worry-free stay for parents and children alike.'

            ]
        ];


        $timestamp = Carbon::now();

        foreach ($roomTypes as $record) {
            $record['created_at'] = $timestamp;
            $record['updated_at'] = null;
        }

        RoomType::insert($roomTypes);
    }
}
