<?php

namespace Database\Seeders;

use App\Models\Room;
use App\Models\RoomType;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Carbon;

class RoomsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $roomTypes = RoomType::all();

        foreach ($roomTypes as $type) {
            for ($i = 1; $i <= 20; $i++) {
                $roomSuffix = str_pad($i, 2, '0', STR_PAD_LEFT); // Ensuring room number is two digits

                $roomNumber = $type['id'] . $roomSuffix;
                // Determine the number of beds based on room type id
                if ($type['id'] == 1) {
                    $numberOfBeds = 1; // Single Room has 1 bed
                } elseif ($type['id'] == 2) {
                    $numberOfBeds = 2; // Double Room has 2 beds
                } else {
                    $numberOfBeds = rand(2, 4); // Other rooms have between 2 and 4 beds randomly
                }

                $timestamp = Carbon::now();


                $rooms[] = [

                    'room_number' => $roomNumber,
                    'number_of_beds' => $numberOfBeds,
                    'room_type_id' => $type['id'],
                    'created_at' => $timestamp
                ];


            }
        }


        Room::insert($rooms);
    }
}
