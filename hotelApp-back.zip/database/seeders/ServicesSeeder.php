<?php

namespace Database\Seeders;

use App\Models\Service;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Carbon;

class ServicesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $services = [
            [
                'name' => 'Rooms & Apartment',
                'image' => 'fa-hotel',
                'description' => 'Experience luxury living with spacious, well-appointed rooms and apartments offering spectacular city and landscape views.'
            ],
            [
                'name' => 'Food & Restaurant',
                'image' => 'fa-utensils',
                'description' => 'Savor exquisite dining options featuring local and international dishes in a sophisticated, inviting atmosphere.'
            ],
            [
                'name' => 'Spa & Fitness',
                'image' => 'fa-spa',
                'description' => 'Relax and rejuvenate with top-notch spa treatments and state-of-the-art fitness facilities tailored to wellness enthusiasts.'
            ],
            [
                'name' => 'Sports & Gaming',
                'image' => 'fa-swimmer',
                'description' => 'Engage in thrilling sports and gaming activities, perfect for families, friends, and professional gamers alike.'
            ],
            [
                'name' => 'Event & Party',
                'image' => 'fa-glass-cheers',
                'description' => 'Host memorable events and parties with our exceptional planning services, modern venues, and dedicated support.'
            ],
            [
                'name' => 'Gym & Yoga',
                'image' => 'fa-dumbbell',
                'description' => 'Keep fit and find your inner peace with our fully equipped gym and yoga classes led by expert instructors.'
            ]
        ];


        $timestamp = Carbon::now();

        foreach ($services as &$record) {
            $record['created_at'] = $timestamp;
            $record['updated_at'] = $timestamp;
        }

        Service::insert($services);
    }
}
