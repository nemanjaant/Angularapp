<!DOCTYPE html>
<html lang="en">
@include('admin_front.fixed.head')

<body class="skin-blue">

<div class="wrapper">

    @include('admin_front.fixed.header')
    @include('admin_front.fixed.sidebar')

    <!-- Right side column. Contains the navbar and content of the page -->
    <div class="content-wrapper">

        <!-- Main content -->
        <section class="content">

            @yield('content')

        </section><!-- /.content -->
    </div><!-- /.content-wrapper -->


    @include('admin_front.fixed.footer')
</div><!-- ./wrapper -->

@include('admin_front.fixed.scripts')
</body>
</html>
