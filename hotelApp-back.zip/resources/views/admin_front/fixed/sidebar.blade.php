<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
        <!-- Sidebar user panel -->
        <div class="user-panel">
            <div class="pull-left info">

            </div>
        </div>


        <ul class="sidebar-menu">
            <li class="header">ADMIN OPERATIONS</li>
            <li class="active treeview">
                <a href="#">
                    <i class="fa fa-dashboard"></i> <span>Display data</span> <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li class="active"><a href="{{route('admin.showRoomTypesAdmin')}}"><i class="fa fa-circle-o"></i> Show Room Types</a></li>
                </ul>
            </li>





            <li>
                <a href="{{route('messages')}}">
                    <i class="fa fa-envelope"></i> <span>Mailbox</span>
                </a>
            </li>


        </ul>
    </section>
    <!-- /.sidebar -->
</aside>
