@extends('admin_front.admin_layout')

@section('content')
    <p>Welcome to Admin page</p>
@endsection
