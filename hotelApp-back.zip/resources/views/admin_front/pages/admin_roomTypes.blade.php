@extends('admin_front.admin_layout')

@section('content')
    <h1>Rooms</h1>



    <table class="table table-dark">
        <thead>
        <tr>
            <th scope="col">#id</th>
            <th scope="col">Name</th>
            <th scope="col" >Description</th>
            <th scope="col">Price</th>
            <th scope="col">Update</th>
            <th scope="col">Delete</th>
        </tr>
        </thead>
        <tbody>
        @foreach($rooms as $room)

        <tr>
            <th scope="row">{{$room->id}}</th>
            <td>{{$room->name}}</td>
            <td>{{$room->description}}</td>
            <td>{{$room->activePrice->price}}</td>
            <td>
                <form action="{{route('roomType.edit', ['id' => $room->id])}}" method="get">
                    @csrf
                    <button type="submit" class="btn btn-info">Edit</button>
                </form>
            </td>
            <td>
                <form action="{{route('roomType.delete', ['id' => $room->id])}}" method="post">
                    @csrf
                    @method('delete')
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </td>
        </tr>

        @endforeach
        </tbody>

        @if($errors->any())
            <h4>{{$errors->first()}}</h4>
        @endif
    </table>
@endsection
