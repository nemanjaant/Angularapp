@extends('admin_front.admin_layout')

@section('content')
    <h1>Edit Room</h1>

    <form action="{{route('roomType.update', ['id' => $room->id])}}" method="post">
        @csrf
        @method('put')
        <div class="form-group">
            <label for="name">Name</label>
            <input type="text" class="form-control" id="name" value="{{$room->name}}" name="name">
            @error('name')
            <p class="text-danger m-0">{{$message}}</p>
            @enderror
        </div>
        <div class="form-group">
            <label for="description">Description</label>
            <input type="text" class="form-control" id="description" value="{{$room->description}}" name="description">
            @error('description')
            <p class="text-danger m-0">{{$message}}</p>
            @enderror
        </div>
        <div class="form-group">
            <label for="description">Price</label>
            <input type="text" class="form-control" id="price" value="{{$room->activePrice->price}}" name="price">
            @error('price')
            <p class="text-danger m-0">{{$message}}</p>
            @enderror
        </div>
        <button type="submit" class="btn btn-primary">Edit</button>
    </form>

    @if(Session::get('error'))
        <p class="alert alert-danger">{{Session::get('error')}}</p>
    @endif
    @if(Session::get('success'))
        <p class="alert alert-success mt-5">{{Session::get('success')}}</p>

    @endif

@endsection
