@extends('admin_front.admin_layout')

@section('content')
    <h1>Messages</h1>

    <table class="table table-dark">
        <thead>
        <tr>
            <th scope="col">Name</th>
            <th scope="col">Email</th>
            <th scope="col" >Subject</th>
            <th scope="col">Message</th>
        </tr>
        </thead>
        <tbody>
        @foreach($messages as $msg)

            <tr>
                <td>{{$msg->name}}</td>
                <td>{{$msg->email}}</td>
                <td>{{$msg->subject}}</td>
                <td>{{$msg->message}}</td>

            </tr>

        @endforeach
        </tbody>

    </table>
@endsection
