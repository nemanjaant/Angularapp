<!-- Booking Start -->
<div class="container-fluid booking pb-5 wow fadeIn" data-wow-delay="0.1s">
    <div class="container">
        <form action="/checkAvailability" method="POST">
            @csrf
            <div class="bg-white shadow" style="padding: 35px;">
                <div class="row g-2">
                    <div class="col-md-10">
                        <div class="row g-2">
                            <div class="col-md-3">
                                <div class="date" id="date1" data-target-input="nearest">
                                    <label for="start-date" class="form-label">Check In</label>
                                    <input type="date" id="start-date" name="start-date" class="form-date" required>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="date" id="date2" data-target-input="nearest">
                                    <label for="end-date" class="form-label">Check Out</label>
                                    <input type="date" id="end-date" name="end-date" class="form-date" required>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <label for="room-type" class="form-label">Room Type</label>

                                <select class="form-select styled-select" name="room-type" id="room-type" onchange="updateMaxInput()">
                                    @if(!$selectedRoomType)
                                    <option disabled selected value="">Select Room Type</option>
                                    @else
                                        <option disabled value="">Select Room Type</option>
                                    @endif
                                    @foreach($rooms as $room)

                                    <option @if($room->id==$selectedRoomType) selected @endif value="{{$room->id}}">{{$room->name}}</option>

                                     @endforeach

                                </select>
                            </div>

                            <div class="col-md-3">
                                <label for="room-type" class="form-label">Number of Guests</label>
                                    <div><button type="button" onclick="decrement()" class="guestCount">-</button>
                                        <input type="text" id="number-input" name="number-input" value="1" min="1" max="4" class="guestNumber">

                                        <button type="button" onclick="increment()" class="guestCount">+</button></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-primary w-100 mt-4">Check Availability</button>
                    </div>

                </div>
            </div>
        </form>
    </div>
</div>
<!-- Booking End -->









<script>

    document.getElementById('start-date').addEventListener('change', function() {
        const startDate = this.value;
        const endDateInput = document.getElementById('end-date');
        if (startDate) {
            endDateInput.min = startDate;
        }
    });

    document.getElementById('end-date').addEventListener('change', function() {
        const endDate = this.value;
        const startDateInput = document.getElementById('start-date');
        if (endDate) {
            startDateInput.max = endDate;
        }
    });

    function increment() {
        var input = document.getElementById('number-input');
        var currentValue = parseInt(input.value);
        if (currentValue < parseInt(input.max)) {
            input.value = currentValue + 1;
        }
    }

    function decrement() {
        var input = document.getElementById('number-input');
        var currentValue = parseInt(input.value);
        if (currentValue > parseInt(input.min)) {
            input.value = currentValue - 1;
        }
    }

    function updateMaxInput() {

        var selectedRoomType = document.getElementById("room-type").value;

        var newMax;

        if (selectedRoomType == 1) {
            newMax = 1;
        } else if (selectedRoomType == 2) {
            newMax = 2;
        } else if (selectedRoomType == 3) {
            newMax = 3;
        } else {
            newMax = 4;
        }

        var numberInput = document.getElementById("number-input");
        numberInput.setAttribute("max", newMax);
        if (numberInput.value > newMax) {
            numberInput.value = newMax;
        }

    }

</script>
