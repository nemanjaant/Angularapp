
<div class="room-item shadow rounded overflow-hidden">
    <div class="position-relative">
        <img class="img-fluid" src="{{asset('img/'.$image)}}" alt="Image of {{$name}}">
        <small
            class="position-absolute start-0 top-100 translate-middle-y bg-primary text-white rounded py-1 px-3 ms-4">${{$price}}/Night</small>
    </div>
    <div class="p-4 mt-2">
        <div class="d-flex justify-content-between mb-3">
            <h5 class="mb-0">{{$name}}</h5>
            <div class="ps-2">
                @for($i = 0; round($i<$rate); $i++)
                <small class="fa fa-star text-primary"></small>
                @endfor
            </div>
        </div>

        <p class="text-body mb-3">{{$description}}</p>
        <!--<div class="d-flex justify-content-between">
            <a class="btn btn-sm btn-primary rounded py-2 px-4" href="route('room.show',['id'=> $id])}}">View Detail</a>
            <a class="btn btn-sm btn-dark rounded py-2 px-4" href="route('rooms.show',['id'=> $id])}}">Book Now</a>
        </div>-->

    </div>
</div>
