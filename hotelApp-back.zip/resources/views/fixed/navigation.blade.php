<nav class="navbar navbar-expand-lg d-inline-flex flex-wrap align-items-center bg-dark navbar-dark w-100">
    <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
        <span class="navbar-toggler-icon"></span>
    </button>


    <div class="collapse navbar-collapse" id="navbarCollapse">

        <div class="row w-100">

            <div class="navbar-nav col-lg-6">
                @foreach($menu as $link)
                    <li class="nav-item">
                        <a class="nav-link @if(request()->routeIs($link->route)) active @endif" href="{{ route($link->route) }}">{{ $link->name }}</a>
                    </li>
                @endforeach
            </div>

            <div class="navbar-nav col-lg-6 d-flex justify-content-end">
                @if(!Auth::check())
                    <div class="logindiv">
                        <form action="{{ route('login') }}" method="GET">
                            <button type="submit" class="btn btn-primary mx-5 w-80">Login/Sign Up</button>
                        </form>
                    </div>
                @else
                    <div class="logindiv">
                        @if(Auth::user()->role_id == 2)
                            <span><a class="nav-link" href="{{ route('admin') }}">Admin page</a></span>
                        @else
                            <span class="mx-3">Welcome, {{ Auth::user()->first_name }}!</span>
                        @endif
                        <form action="{{ route('logout') }}" method="POST" class="ms-2">
                            @csrf
                            <button type="submit" class="btn btn-primary">Logout</button>
                        </form>
                    </div>
                @endif
            </div>

        </div>

    </div>




</nav>
