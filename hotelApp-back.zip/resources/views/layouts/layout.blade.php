
<!DOCTYPE html>

<html lang="en">

@include('fixed.head')

<body>

@include('fixed.header')

<div class="container-xxl bg-white p-0">
@yield('content')
</div>
@include('fixed.footer')

@include('fixed.scripts')
</body>

</html>
