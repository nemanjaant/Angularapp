@extends('layouts.layout')
@section('title')
    About
@endsection

@section('keywords')
    kw1, kw2, kw3
@endsection

@section('description')
    About page
@endsection

@section('content')
    <!-- About Start -->
    <div class="container-xxl py-5">
        <div class="container">
            <div class="row g-5 align-items-center">
                <div class="col-lg-6">
                    <h6 class="section-title text-start text-primary text-uppercase">About Us</h6>
                    <h1 class="mb-4">Welcome to <span class="text-primary text-uppercase">Hotelier</span></h1>
                    <p class="mb-4">Welcome to Hotelier, the pinnacle of luxury and refinement where exceptional service meets contemporary elegance. Nestled in the heart of the city, our 5-star property promises an unforgettable experience for discerning travelers seeking the utmost in comfort and pampering.</p>

                    <p class="mb-4">From the moment you step through our doors, you will be enveloped in an atmosphere of sophistication and tranquility. Hotelier is designed to cater to every need and desire, ensuring that each guest's stay is nothing short of spectacular. Our beautifully appointed rooms and suites offer unparalleled views and lavish amenities, creating a perfect haven of relaxation.</p>

                    <p class="mb-4">Step into a world where luxury is the standard and every stay is an extraordinary adventure. Welcome to Hotelier, where your journey into the extraordinary begins.</p>


                </div>
                <div class="col-lg-6">
                    <div class="row g-3">
                        <div class="col-6 text-end">
                            <img class="img-fluid rounded w-75 wow zoomIn" data-wow-delay="0.1s" src="img/about-1.jpg"
                                 style="margin-top: 25%;">
                        </div>
                        <div class="col-6 text-start">
                            <img class="img-fluid rounded w-100 wow zoomIn" data-wow-delay="0.3s" src="img/about-2.jpg">
                        </div>
                        <div class="col-6 text-end">
                            <img class="img-fluid rounded w-50 wow zoomIn" data-wow-delay="0.5s" src="img/about-3.jpg">
                        </div>
                        <div class="col-6 text-start">
                            <img class="img-fluid rounded w-75 wow zoomIn" data-wow-delay="0.7s" src="img/about-4.jpg">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- About End -->

    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-12 p-5 text-justify" id="author">
                <p>Nemanja Antanasijević (<a href="https://www.linkedin.com/in/nemanja-antanasijevi%C4%87-34289b168/"
                                             target="_blank" style="color:blue">LinkedIn</a>), student Visoke ICT škole. Radi za kompaniju MDPI, na poziciji
                    produkcijskog urednika. </p>

            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 p-5 text-center" id="author">

                <img src="{{asset('img/ik.png')}}" class="img-fluid" alt="Autor sajta">

            </div>
        </div>
    </div>

@endsection
