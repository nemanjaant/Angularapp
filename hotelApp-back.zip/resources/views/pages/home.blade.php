@extends('layouts.layout')

@section('title')
    Home
@endsection

@section('keywords')
    kw1, kw2, kw3
@endsection

@section('description')
    Home page
@endsection

@section('content')

    <!-- Upon successful registration user will be redirected to homepage and receive the message -->
    @if (session('success'))
        <div id="successMessage" class="card alert alert-success">
            {{ session('success') }}
        </div>

    @endif

    @include('partials.carousel',$carouselImages)

    <x-reservation-form :rooms="$rooms"/>



    <!-- Room Start -->
    @include('partials.rooms', $rooms)
    <!-- Room End -->



    <!-- Service Start -->
    @include('partials.services', $services)
    <!-- Service End -->




    <!-- Newsletter Start -->
    @include('partials.newsletter')
    <!-- Newsletter Start -->
@endsection
