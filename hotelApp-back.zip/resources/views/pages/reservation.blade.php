@extends('layouts.layout')

@section('title')
    Reservation
@endsection

@section('keywords')
    kw1, kw2, kw3
@endsection

@section('description')
    Reservation page
@endsection

@section('content')

    <div style="height: 30vh;background-color: rgba(0, 0, 0, 0.5);">
        <img src="{{asset('img/carousel-2.jpg')}}" style="width: auto">
    </div>

    <x-reservation-form :rooms="$roomTypes"/>



    @if(!$room)
        <div id="info-box">
            <p>Sorry! There are no rooms available for the selected dates.</p>
        </div>
    @else
        <div id="info-box">
            <input type="hidden" id="start-date-hidden" name="start-date" value="{{ $startDate }}">
            <input type="hidden" id="end-date-hidden" name="end-date" value="{{ $endDate }}">
            <input type="hidden" id="room-id-hidden" name="room-id" value="{{ $room->id }}">

            <p>Thank you for choosing to stay in our hotel! The price of your reservation is ${{$room->room_price}}  </p>
            <button class="btn btn-primary" id="confirm-btn">confirm reservation</button>
        </div>
    @endif



@endsection
