@extends('layouts.layout')

@section('title')
    Home
@endsection

@section('keywords')
    kw1, kw2, kw3
@endsection

@section('description')
    Home page
@endsection

@section('content')






    <!-- Newsletter Start -->
    @include('partials.newsletter')
    <!-- Newsletter Start -->
@endsection
