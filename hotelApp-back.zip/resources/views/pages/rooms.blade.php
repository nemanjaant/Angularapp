@extends('layouts.layout')

@section('title')
    Rooms
@endsection

@section('keywords')
    kw1, kw2, kw3
@endsection

@section('description')
    Rooms page
@endsection

@section('content')

    <div style="height: 20vh;background-color: rgba(0, 0, 0, 0.5);">

    </div>

    <x-reservation-form :rooms="$rooms" :selectedRoomType="$id"/>
    @if(!$id)

        <div class="container testimonial my-3">
        <div class="row">


            <div class="col-lg-2">


                <div class="row filters">
                    <p>Room rates</p>
                    <div class="form-control">
                        <label for="5"><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span></label>
                        <input type="checkbox" name="rates[]" value="5" id="5">
                    </div>

                    <div class="form-control">
                        <label for="4"><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span></label>
                        <input type="checkbox" name="rates[]" value="4" id="4">
                    </div>
                    <div class="form-control">
                        <label for="3"><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span></label>
                        <input type="checkbox" name="rates[]" value="3" id="3">
                    </div>
                    <div class="form-control">
                        <label for="2"><span class="fa fa-star"></span><span class="fa fa-star"></span></label>
                        <input type="checkbox" name="rates[]" value="2" id="2">
                    </div>
                    <div class="form-control">
                        <label for="1"><span class="fa fa-star"></span></label>
                        <input type="checkbox" name="rates[]" value="1" id="1">
                    </div>

                </div>
                <div class="row filters">
                    <p>Price Range</p>
                    <div class="form-control">
                        <label for="min">Min.</label>
                        <input type="input" id="min">
                    </div>

                    <div class="form-control">
                        <label for="max">Max.</label>
                        <input type="input"  id="max">
                    </div>

                </div>

                <div class="row">
                    <div class="form-control">
                        <button onclick="applyFilter()" class="btn btn-light">Filter</button>
                    </div>
                    <div class="form-control">
                        <button onclick="resetFilter()" class="btn btn-light">Reset</button>
                    </div>
                </div>

            </div>

            <div class="col-lg-10" id="rooms">

                @include('partials.rooms', $rooms)

            </div>
        </div>


    </div>
    @endif








    <!-- Testimonial Start
    <div class="container-xxl testimonial my-5 py-5 bg-dark wow zoomIn" data-wow-delay="0.1s">
        <div class="container">
            <div class="owl-carousel testimonial-carousel py-5">
                <div class="testimonial-item position-relative bg-white rounded overflow-hidden">
                    <p>Tempor stet labore dolor clita stet diam amet ipsum dolor duo ipsum rebum stet dolor amet diam
                        stet. Est stet ea lorem amet est kasd kasd et erat magna eos</p>
                    <div class="d-flex align-items-center">
                        <img class="img-fluid flex-shrink-0 rounded" src="img/testimonial-1.jpg"
                             style="width: 45px; height: 45px;">
                        <div class="ps-3">
                            <h6 class="fw-bold mb-1">Client Name</h6>
                            <small>Profession</small>
                        </div>
                    </div>
                    <i class="fa fa-quote-right fa-3x text-primary position-absolute end-0 bottom-0 me-4 mb-n1"></i>
                </div>
                <div class="testimonial-item position-relative bg-white rounded overflow-hidden">
                    <p>Tempor stet labore dolor clita stet diam amet ipsum dolor duo ipsum rebum stet dolor amet diam
                        stet. Est stet ea lorem amet est kasd kasd et erat magna eos</p>
                    <div class="d-flex align-items-center">
                        <img class="img-fluid flex-shrink-0 rounded" src="img/testimonial-2.jpg"
                             style="width: 45px; height: 45px;">
                        <div class="ps-3">
                            <h6 class="fw-bold mb-1">Client Name</h6>
                            <small>Profession</small>
                        </div>
                    </div>
                    <i class="fa fa-quote-right fa-3x text-primary position-absolute end-0 bottom-0 me-4 mb-n1"></i>
                </div>
                <div class="testimonial-item position-relative bg-white rounded overflow-hidden">
                    <p>Tempor stet labore dolor clita stet diam amet ipsum dolor duo ipsum rebum stet dolor amet diam
                        stet. Est stet ea lorem amet est kasd kasd et erat magna eos</p>
                    <div class="d-flex align-items-center">
                        <img class="img-fluid flex-shrink-0 rounded" src="img/testimonial-3.jpg"
                             style="width: 45px; height: 45px;">
                        <div class="ps-3">
                            <h6 class="fw-bold mb-1">Client Name</h6>
                            <small>Profession</small>
                        </div>
                    </div>
                    <i class="fa fa-quote-right fa-3x text-primary position-absolute end-0 bottom-0 me-4 mb-n1"></i>
                </div>
            </div>
        </div>
    </div>
 Testimonial End -->
@endsection
