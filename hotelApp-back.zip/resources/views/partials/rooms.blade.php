<div class="container-xxl py-5">
    <div class="container">
        @if($isHomePage)
        <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
            <h6 class="section-title text-center text-primary text-uppercase">Our Rooms</h6>
            <h1 class="mb-5">Explore Our <span class="text-primary text-uppercase">Rooms</span></h1>
        </div>
        @endif
        <div class="row g-4">
            @foreach($rooms as $room)
            <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.{{$loop->index+2}}s">
                <x-room-card :price="$room->activePrice->price" :image="$room->primaryImage->src" :name="$room->name" :rate="$room->averageRate" :description="$room->description"
                             :id="$room->id" />

            </div>
            @endforeach
        </div>
    </div>
</div>
