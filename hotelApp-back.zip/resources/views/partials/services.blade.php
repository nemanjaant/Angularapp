<div class="container-xxl py-5">
    <div class="container">
        <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
            <h6 class="section-title text-center text-primary text-uppercase">Our Services</h6>
            <h1 class="mb-5">Explore Our <span class="text-primary text-uppercase">Services</span></h1>
        </div>
        <div class="row g-4">
            @foreach($services as $service)
                <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.{{$loop->index+1}}s">
                    <div class="service-item rounded">
                        <div class="service-icon bg-transparent border rounded p-1">
                            <div class="w-100 h-100 border rounded d-flex align-items-center justify-content-center">
                                <i class="fa {{$service->image}} fa-2x text-primary"></i>
                            </div>
                        </div>
                        <h5 class="mb-3">{{$service->name}}</h5>
                        <p class="text-body mb-0">{{$service->description}}</p>
                    </div>
                </div>

            @endforeach



        </div>
    </div>
</div>
