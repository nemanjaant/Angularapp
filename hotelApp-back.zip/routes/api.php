<?php

use App\Http\Controllers\ContactController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\MenuController;
use App\Http\Controllers\NewsletterController;
use App\Http\Controllers\ReservationController;
use App\Http\Controllers\RoomController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/


Route::get('/', [HomeController::class, 'index']);
Route::get('/getMenu', [MenuController::class, 'getMenu']);
Route::get('/getRoomTypes', [RoomController::class, 'showRoomTypes']);

Route::get('/home', [HomeController::class,'index'])->name('home');

Route::get('/about', function(){
    return view('pages.about');})->name('about');

Route::get('/contact', [ContactController::class,'contactPage'])->name('contact');

Route::post('/submit', [ContactController::class,'processContactFormData'])->name('submit');


Route::get('/rooms',[RoomController::class,'showRooms'])->name('rooms');
Route::post('/rooms/getAllRooms',[RoomController::class,'getAllRooms'])->name('roomsAjax');

Route::get('/rooms/{id}',[RoomController::class,'showRooms'])->name('rooms.show');
//Route::get('/room/{id}',[RoomController::class,'showRoom'])->name('room.show');
Route::post('/rooms/filter', [RoomController::class,'filterRooms'])->name('rooms.filter');


Route::post('/checkAvailability',[ReservationController::class, 'checkAvailability'])->name('checkAvailability');
Route::post('/makeReservation',[ReservationController::class, 'makeReservation'])->name('makeReservation');
Route::delete('/deleteReservation/{id}',[ReservationController::class, 'deleteReservation'])->name('deleteReservation');
Route::get('/subscribeToNewsletter/{email}', [NewsletterController::class, 'subscribe'])->name('subscribeToNewsletter');



